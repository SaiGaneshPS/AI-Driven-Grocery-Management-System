import re
import requests
from collections import defaultdict
import json

class OCRProcessor:
    def process_ocr_text(ocr_text):
            barcode_pattern = re.compile(r'\b\d{12}\b')
            barcodes = barcode_pattern.findall(ocr_text)
            print("Barcodes found:", barcodes)

            # Map to store barcodes, item names, corrected prices, and quantities
            barcode_price_map = defaultdict(lambda: {'name': '', 'price': 0, 'quantity': 0})

            # Function to correct prices
            def correct_price(text, barcode_position):
                barcode_index = text.find(barcode_position)
                if barcode_index != -1:
                    segment = text[barcode_index + len(barcode_position):].strip()
                    
                    # Replace the first non-$ character after the barcode with $
                    if segment and segment[0] != '$':
                        segment = '$' + segment[1:]
                    
                    # Find the price pattern
                    price_match = re.search(r'\$\d+[.,]?\d*', segment)
                    if price_match:
                        price_str = price_match.group(0)
                        # Replace any commas with dots and ensure two decimal places
                        corrected_price = re.sub(r'(\$)(\d+)[.,]?(\d*)', lambda m: f"${m.group(2)}.{m.group(3).ljust(2, '0')}", price_str)
                        return corrected_price
                    
                return None

            # Function to extract item name from text
            def extract_item_name(text, barcode):
                # Split the text into lines
                lines = text.split('\n')
                
                # Iterate through each line to find the one containing the barcode
                for line in lines:
                    if barcode in line:
                        # Extract the item name from the line containing the barcode
                        barcode_index = line.find(barcode)
                        item_name = line[:barcode_index].strip()
                        return item_name
                return ''

            # Function to calculate check digit
            def calculate_check_digit(barcode):
                digits = [int(d) for d in barcode]
                sum1 = sum(digits[i] for i in range(0, 11, 2))
                sum2 = sum(digits[i] for i in range(1, 10, 2))
                total_sum = (sum1 * 3) + sum2
                check_digit = (10 - (total_sum % 10)) % 10
                return check_digit

            # Function to get item information from Open Food Facts API
            def get_item_info(barcode):
                url = f"https://world.openfoodfacts.org/api/v0/product/{barcode}.json"
                response = requests.get(url)
                if response.status_code == 200:
                    data = response.json()
                    product_name = data.get("product", {}).get("product_name", "Unknown")
                    return product_name
                return "Unknown"

            # Process each barcode to find and correct the price and item name
            for barcode in barcodes:
                # Correct price
                price = correct_price(ocr_text, barcode)
                if price:
                    price_float = float(price.replace('$', '').replace(',', '.'))
                    barcode_price_map[barcode]['price'] = price_float
                    barcode_price_map[barcode]['quantity'] += 1

                # Extract item name
                item_name = extract_item_name(ocr_text, barcode)
                if item_name:
                    barcode_price_map[barcode]['name'] = item_name

            # Replace the last digit of the barcode with the check digit
            corrected_barcodes = []
            for barcode in list(barcode_price_map.keys()):
                if len(barcode) == 12:
                    check_digit = calculate_check_digit(barcode[:-1])
                    corrected_barcode = barcode[:-1] + str(check_digit)
                    corrected_barcodes.append(corrected_barcode)
                    # Update the barcode-price map with the corrected barcode
                    if barcode in barcode_price_map:
                        barcode_price_map[corrected_barcode] = barcode_price_map.pop(barcode)

            # Get item names and nutritional values for corrected barcodes and update the map
            for barcode in corrected_barcodes:
                item_name = get_item_info(barcode)
                if item_name == "Unknown":
                    item_name = barcode_price_map[barcode]['name']
                barcode_price_map[barcode]['name'] = item_name

            # # Calculate the subtotal and grand total with HST (15%)
            # subtotal = sum(item['price'] * item['quantity'] for item in barcode_price_map.values())
            # hst = subtotal * 0.15
            # grand_total = subtotal + hst

            # # Print barcode-price-map and totals
            # print("Subtotal:", subtotal)
            # print("HST (15%):", hst)
            # print("Grand Total:", grand_total)

            # Convert to JSON format
            output = []
            for barcode, data in barcode_price_map.items():
                item = {
                    'Item Name': data['name'],
                    'Item Price': data['price'],
                    'Item Quantity': data['quantity'],
                }
                output.append(item)

            json_output = json.dumps(output, indent=4)
            #print("JSON Output:", json_output)
            return json_output