from kivymd.uix.screen import MDScreen

class GenerateRecipeScreen(MDScreen):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.name = "generate_recipe_screen"
        # Add the recipe generation functionality later
